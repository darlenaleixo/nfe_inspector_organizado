# -*- coding: utf-8 -*-
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
import threading
import os


# Importações do projeto
from processing.processor import NFeProcessor
from ui.web import iniciar_dashboard_web
from core.config import config_manager # <-- Nova importação

def iniciar_gui():
    """Cria e executa a interface gráfica principal do aplicativo."""
    root = tk.Tk()
    root.title("Analisador de NFe/NFCe")
    root.geometry("600x450")
    root.minsize(500, 400)

    style = ttk.Style()
    style.theme_use('clam')
    style.configure("TButton", padding=6, relief="flat", background="#007bff", foreground="white")
    style.map("TButton", background=[('active', '#0056b3')])

    main_frame = ttk.Frame(root, padding="20")
    main_frame.pack(fill=tk.BOTH, expand=True)

    # Variáveis de controle
    xml_folder = tk.StringVar()
    output_folder = tk.StringVar()

    # --- LÓGICA DE CONFIGURAÇÃO ---
    # Carrega os últimos caminhos usados do config.ini
    xml_folder.set(config_manager.get('PADRAO', 'pasta_xml'))
    output_folder.set(config_manager.get('PADRAO', 'pasta_saida'))

    processor = NFeProcessor(xml_folder.get(), output_folder.get())

    # --- Funções de Callback ---
    def selecionar_pasta(variavel_tk, titulo, config_key):
        path = filedialog.askdirectory(title=titulo, initialdir=variavel_tk.get() or os.path.expanduser("~"))
        if path:
            variavel_tk.set(path)
            # Salva o novo caminho no config.ini
            config_manager.set('PADRAO', config_key, path)
            config_manager.save()

    def executar_processamento():
        if not xml_folder.get() or not output_folder.get():
            messagebox.showwarning("Atenção", "Por favor, selecione a pasta de XMLs e a pasta de saída.")
            return

        processor.pasta_xml = xml_folder.get()
        processor.pasta_saida = output_folder.get()

        # Desabilita botões durante o processamento
        btn_processar.config(state=tk.DISABLED, text="Processando...")
        btn_dashboard.config(state=tk.DISABLED)
        
        # Barra de progresso
        progress = ttk.Progressbar(main_frame, mode='indeterminate')
        progress.grid(row=5, column=0, columnspan=2, sticky="ew", pady=(10, 0))
        progress.start(10)

        def thread_target():
            processor.processar_pasta()
            processor.calcular_resumos()
            processor.gerar_relatorios()
            
            # Reabilita os botões na thread principal
            root.after(0, on_processing_complete)

        threading.Thread(target=thread_target, daemon=True).start()

    def on_processing_complete():
        # Para a barra de progresso e a remove
        for widget in main_frame.winfo_children():
            if isinstance(widget, ttk.Progressbar):
                widget.stop()
                widget.destroy()

        btn_processar.config(state=tk.NORMAL, text="Iniciar Processamento")
        btn_dashboard.config(state=tk.NORMAL)
        messagebox.showinfo("Sucesso", f"Processamento concluído!\nRelatórios salvos em: {processor.pasta_saida}")

    def abrir_dashboard():
        if not processor.dados_processados:
            messagebox.showwarning("Atenção", "Nenhum dado foi processado ainda. Execute o processamento primeiro.")
            return
        threading.Thread(target=iniciar_dashboard_web, args=(processor,), daemon=True).start()

    # --- Layout da GUI ---
    ttk.Label(main_frame, text="Analisador de Notas Fiscais", font=("Segoe UI", 18, "bold")).grid(row=0, column=0, columnspan=2, pady=(0, 20))

    # Seleção de Pasta XML
    ttk.Label(main_frame, text="Pasta com arquivos XML:", font=("Segoe UI", 10)).grid(row=1, column=0, columnspan=2, sticky="w")
    entry_xml = ttk.Entry(main_frame, textvariable=xml_folder, width=50)
    entry_xml.grid(row=2, column=0, sticky="ew", padx=(0, 5))
    btn_xml = ttk.Button(main_frame, text="Selecionar...", command=lambda: selecionar_pasta(xml_folder, "Selecione a pasta com os XMLs", 'pasta_xml'))
    btn_xml.grid(row=2, column=1, sticky="ew")

    # Seleção de Pasta de Saída
    ttk.Label(main_frame, text="Pasta para salvar relatórios:", font=("Segoe UI", 10)).grid(row=3, column=0, columnspan=2, sticky="w", pady=(10, 0))
    entry_output = ttk.Entry(main_frame, textvariable=output_folder, width=50)
    entry_output.grid(row=4, column=0, sticky="ew", padx=(0, 5))
    btn_output = ttk.Button(main_frame, text="Selecionar...", command=lambda: selecionar_pasta(output_folder, "Selecione a pasta para salvar os relatórios", 'pasta_saida'))
    btn_output.grid(row=4, column=1, sticky="ew")

    # Botões de Ação
    btn_processar = ttk.Button(main_frame, text="Iniciar Processamento", command=executar_processamento)
    btn_processar.grid(row=6, column=0, columnspan=2, sticky="ew", pady=(20, 10))

    btn_dashboard = ttk.Button(main_frame, text="Abrir Dashboard Web", command=abrir_dashboard)
    btn_dashboard.grid(row=7, column=0, columnspan=2, sticky="ew")

    # Configuração de expansão das colunas
    main_frame.columnconfigure(0, weight=1)

    root.mainloop()

if __name__ == "__main__":
    # Este ficheiro é importado, não executado diretamente
    pass
