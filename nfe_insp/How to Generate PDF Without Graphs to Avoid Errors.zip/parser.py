#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Módulo de Parsing de XML para NFe/NFCe.

Contém as funções responsáveis por ler os arquivos XML, extrair os dados,
validar a estrutura e sanitizar os campos de texto.
"""
import os
import logging
import re
import xml.etree.ElementTree as ET
from typing import Dict, List, Optional, Any, Set

# --- Constantes ---
NFE_NS = {"nfe": "http://www.portalfiscal.inf.br/nfe"}

# --- Funções Utilitárias de Parsing ---

def _sanitizar(texto: str) -> str:
    """
    Remove caracteres de controle, espaços extras e quebras de linha.
    """
    if not isinstance(texto, str):
        return ""
    texto = "".join(c for c in texto if c.isprintable())
    texto = re.sub(r'\s+', ' ', texto).strip()
    return texto

def _text(node: Optional[ET.Element]) -> str:
    """
    Extrai e sanitiza o texto de um elemento XML de forma segura.
    """
    raw_text = node.text.strip() if node is not None and node.text else ""
    return _sanitizar(raw_text)

def _find(node: ET.Element, path: str) -> Optional[ET.Element]:
    """Busca um único elemento XML usando o namespace NFE_NS."""
    if node is None:
        return None
    return node.find(path, NFE_NS)

def _findall(node: ET.Element, path: str) -> List[ET.Element]:
    """Busca todos os elementos XML que correspondem ao caminho usando o namespace NFE_NS."""
    if node is None:
        return []
    return node.findall(path, NFE_NS)

# --- Lógica de Extração de Dados ---

def coletar_chaves_canceladas(pasta: str) -> Set[str]:
    """
    Varre a pasta em busca de XMLs de evento de cancelamento (tpEvento=110111)
    e retorna um conjunto com as chaves das notas canceladas.
    """
    canceladas = set()
    logging.info("Iniciando coleta de informações de notas canceladas...")
    for root, _, files in os.walk(pasta):
        for f in files:
            if f.lower().endswith(".xml"):
                fp = os.path.join(root, f)
                try:
                    tree = ET.parse(fp)
                    if _text(_find(tree.getroot(), ".//nfe:infEvento/nfe:tpEvento")) == "110111":
                        ch_nfe = _text(_find(tree.getroot(), ".//nfe:infEvento/nfe:chNFe"))
                        if ch_nfe:
                            canceladas.add(ch_nfe)
                except ET.ParseError:
                    logging.debug(f"Erro de parsing em {fp} (ignorado, pode não ser um XML de evento).")
                except Exception as e:
                    logging.error(f"Erro inesperado ao processar {fp} para cancelamento: {e}")
    logging.info(f"Foram encontradas {len(canceladas)} notas fiscais canceladas.")
    return canceladas

def parse_nfe_nfce_xml(fp: str, chaves_canceladas: Set[str]) -> List[Dict[str, Any]]:
    """
    Processa um único arquivo XML de NFe/NFCe, validando sua estrutura
    e extraindo todos os dados relevantes de forma sanitizada.
    """
    try:
        tree = ET.parse(fp)
        r = tree.getroot()
    except ET.ParseError as e:
        logging.error(f"Erro de parsing no XML {fp}: {e}")
        return []

    infNFe = _find(r, ".//nfe:infNFe") or _find(r, ".//nfe:NFe/nfe:infNFe")
    if infNFe is None:
        logging.warning(f"VALIDAÇÃO FALHOU: Tag <infNFe> não encontrada em {fp}. Arquivo ignorado.")
        return []

    ide = _find(infNFe, "nfe:ide")
    emit = _find(infNFe, "nfe:emit")
    det_list = _findall(infNFe, "nfe:det")
    if not all([ide, emit, det_list]):
        logging.warning(f"VALIDAÇÃO FALHOU: Estrutura mínima (ide, emit, det) não encontrada em {fp}. Arquivo ignorado.")
        return []
    
    ide = ide or ET.Element("ide")
    emit = emit or ET.Element("emit")
    dest = _find(infNFe, "nfe:dest") or ET.Element("dest")
    total = _find(infNFe, "nfe:total/nfe:ICMSTot") or ET.Element("ICMSTot")

    chave = infNFe.attrib.get("Id", "").replace("NFe", "")
    status = "Cancelada" if chave in chaves_canceladas else "Autorizada"

    dados_gerais = {
        "status": status, "arquivo": os.path.basename(fp), "chave_acesso": chave,
        "modelo_doc": _text(_find(ide, "nfe:mod")), "serie": _text(_find(ide, "nfe:serie")),
        "numero_nf": _text(_find(ide, "nfe:nNF")), "data_emissao": _text(_find(ide, "nfe:dhEmi")),
        "valor_total_nf": _text(_find(total, "nfe:vNF")), "valor_total_produtos": _text(_find(total, "nfe:vProd")),
        "emit_cnpj": _text(_find(emit, "nfe:CNPJ")), "emit_nome": _text(_find(emit, "nfe:xNome")),
        "dest_cnpj_cpf": _text(_find(dest, "nfe:CNPJ")) or _text(_find(dest, "nfe:CPF")),
        "dest_nome": _text(_find(dest, "nfe:xNome")),
    }

    pagamentos = []
    mapa_pagamento = {
        "01": "Dinheiro", "02": "Cheque", "03": "Cartão de Crédito", "04": "Cartão de Débito",
        "05": "Crédito Loja", "10": "Vale Alimentação", "11": "Vale Refeição", "12": "Vale Presente",
        "13": "Vale Combustível", "14": "Duplicata Mercantil", "15": "Boleto Bancário",
        "16": "Depósito Bancário", "17": "PIX", "18": "Transferência Bancária",
        "19": "Carteira Digital", "90": "Sem Pagamento", "99": "Outros"
    }
    for pag in _findall(infNFe, "nfe:pag/nfe:detPag"):
        cod_pag = _text(_find(pag, "nfe:tPag"))
        desc_pag = mapa_pagamento.get(cod_pag, f"Cód:{cod_pag}")
        valor_pag = _text(_find(pag, "nfe:vPag"))
        pagamentos.append(f"{desc_pag}={valor_pag}")
    dados_gerais["pagamentos"] = "; ".join(pagamentos)

    linhas_finais = []
    for det in det_list:
        prod = _find(det, "nfe:prod") or ET.Element("prod")
        imposto = _find(det, "nfe:imposto") or ET.Element("imposto")
        
        item_dados = {
            "item_numero": det.attrib.get("nItem", ""), 
            "item_codigo": _text(_find(prod, "nfe:cProd")),
            "item_descricao": _text(_find(prod, "nfe:xProd")),
            "item_cfop": _text(_find(prod, "nfe:CFOP")),
            "item_quantidade": _text(_find(prod, "nfe:qCom")),
            "item_valor_unitario": _text(_find(prod, "nfe:vUnCom")), 
            "item_valor_total": _text(_find(prod, "nfe:vProd")),
        }

        # --- LÓGICA DE EXTRAÇÃO DE IMPOSTOS COMPLETAMENTE REFEITA ---
        impostos_dados = {}
        
        # --- ICMS ---
        icms_tag = _find(imposto, 'nfe:ICMS')
        if icms_tag is not None and len(icms_tag) > 0:
            icms_node = icms_tag[0] # Pega o grupo específico (ex: ICMS00, ICMSSN102)
            impostos_dados["icms_cst"] = _text(_find(icms_node, "nfe:CST")) or _text(_find(icms_node, "nfe:CSOSN"))
            impostos_dados["icms_vbc"] = _text(_find(icms_node, "nfe:vBC"))
            impostos_dados["icms_picms"] = _text(_find(icms_node, "nfe:pICMS"))
            impostos_dados["icms_vicms"] = _text(_find(icms_node, "nfe:vICMS"))
            impostos_dados["icms_vbcst"] = _text(_find(icms_node, "nfe:vBCST"))
            impostos_dados["icms_vicmsst"] = _text(_find(icms_node, "nfe:vICMSST"))

        # --- IPI ---
        ipi_tag = _find(imposto, 'nfe:IPI')
        if ipi_tag is not None and len(ipi_tag) > 0:
            ipi_node = ipi_tag[0] # Pega o grupo específico (ex: IPITrib, IPINT)
            impostos_dados["ipi_cst"] = _text(_find(ipi_node, "nfe:CST"))
            impostos_dados["ipi_vbc"] = _text(_find(ipi_node, "nfe:vBC"))
            impostos_dados["ipi_pipi"] = _text(_find(ipi_node, "nfe:pIPI"))
            impostos_dados["ipi_vipi"] = _text(_find(ipi_node, "nfe:vIPI"))

        # --- PIS ---
        pis_tag = _find(imposto, 'nfe:PIS')
        if pis_tag is not None and len(pis_tag) > 0:
            pis_node = pis_tag[0] # Pega o grupo específico (ex: PISAliq, PISNT)
            impostos_dados["pis_cst"] = _text(_find(pis_node, "nfe:CST"))
            impostos_dados["pis_vbc"] = _text(_find(pis_node, "nfe:vBC"))
            impostos_dados["pis_ppis"] = _text(_find(pis_node, "nfe:pPIS"))
            impostos_dados["pis_vpis"] = _text(_find(pis_node, "nfe:vPIS"))

        # --- COFINS ---
        cofins_tag = _find(imposto, 'nfe:COFINS')
        if cofins_tag is not None and len(cofins_tag) > 0:
            cofins_node = cofins_tag[0] # Pega o grupo específico (ex: COFINSAliq, COFINSNT)
            impostos_dados["cofins_cst"] = _text(_find(cofins_node, "nfe:CST"))
            impostos_dados["cofins_vbc"] = _text(_find(cofins_node, "nfe:vBC"))
            impostos_dados["cofins_pcofins"] = _text(_find(cofins_node, "nfe:pCOFINS"))
            impostos_dados["cofins_vcofins"] = _text(_find(cofins_node, "nfe:vCOFINS"))
        
        # Junta todos os dicionários numa única linha
        linhas_finais.append({**dados_gerais, **item_dados, **impostos_dados})

    return linhas_finais

